# proyecto3
Zonatops
Tops de música variada clasificando premios Grammy y vistas en youtube

¿Quiénes son los principales usuarios del producto?

Los principales usuarios son las personas quienes quieran saber cuales han sido las mejores canciones de las ultimas décadas.



¿Cuáles son los objetivos de estos usuarios en relación con tu producto?

El objetivo de nuestros usuarios es de conocer cuales fueron las mejores canciones de las ultimas década y/o 
encontrar una canción por medio de nuestro reproductor añadido en las paginas que muestran la información.



¿Cómo crees que el producto que estás creando está resolviendo sus problemas?

Como un buen amante de la música latina tenemos que satisfacer la curiosidad de nuestros usuarios sobre sus canciones favoritas,
resolvemos sus problemas al brindarle una selección de canciones variadas de géneros desde salsa hasta el reguetón antiguo,
así como una informacion sobre los artistas que participaron en su éxito musical favorito.
